const OpenAI = require('openai');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

class AIService {
  async generateLearningPath(goal, skillLevel, learningStyle) {
    try {
      const prompt = `You are an expert educational content creator. Generate a comprehensive, personalized learning path for the following:

Goal: ${goal}
Current Skill Level: ${skillLevel}
Learning Style: ${learningStyle}

Create a structured learning path with 3-5 modules. For each module, include:
1. Module title
2. Description (2-3 sentences)
3. Key topics (3-5 topics)
4. Estimated duration in hours
5. Learning objectives (3-4 objectives)
6. Recommended resources or activities

Return ONLY valid JSON in this exact format:
{
  "title": "Learning path title",
  "description": "Overall description",
  "difficulty": "${skillLevel}",
  "estimatedDuration": total_hours,
  "modules": [
    {
      "id": "module_1",
      "title": "Module title",
      "description": "Module description",
      "topics": ["topic1", "topic2", "topic3"],
      "duration": hours,
      "objectives": ["objective1", "objective2"],
      "resources": ["resource1", "resource2"]
    }
  ]
}`;

      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are an expert educational content creator. Always respond with valid JSON only." },
          { role: "user", content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 2000
      });

      const content = response.choices[0].message.content.trim();
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      
      if (!jsonMatch) {
        throw new Error('No valid JSON found in response');
      }

      return JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('Error generating learning path:', error);
      throw error;
    }
  }

  async generateQuiz(moduleTopic, difficulty, numQuestions = 5) {
    try {
      const prompt = `Generate ${numQuestions} multiple-choice quiz questions about: ${moduleTopic}
Difficulty level: ${difficulty}

Return ONLY valid JSON in this format:
{
  "questions": [
    {
      "id": "q1",
      "question": "Question text?",
      "options": ["Option A", "Option B", "Option C", "Option D"],
      "correctAnswer": 0,
      "explanation": "Explanation of the correct answer"
    }
  ]
}`;

      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are an expert quiz creator. Always respond with valid JSON only." },
          { role: "user", content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 1500
      });

      const content = response.choices[0].message.content.trim();
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      
      if (!jsonMatch) {
        throw new Error('No valid JSON found in response');
      }

      return JSON.parse(jsonMatch[0]);
    } catch (error) {
      console.error('Error generating quiz:', error);
      throw error;
    }
  }

  async getTutoringResponse(question, context) {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4",
        messages: [
          { role: "system", content: "You are a helpful and patient tutor. Provide clear, educational explanations tailored to the student's level." },
          { role: "user", content: `Context: ${context}\n\nQuestion: ${question}` }
        ],
        temperature: 0.7,
        max_tokens: 500
      });

      return response.choices[0].message.content;
    } catch (error) {
      console.error('Error getting tutoring response:', error);
      throw error;
    }
  }
}

module.exports = new AIService();